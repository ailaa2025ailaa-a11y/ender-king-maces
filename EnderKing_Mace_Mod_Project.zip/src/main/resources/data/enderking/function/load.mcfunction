scoreboard objectives add ek_kills dummy
scoreboard objectives add ek_tier dummy
scoreboard objectives add ek_tier_last dummy
scoreboard objectives add ek_deaths deathCount
