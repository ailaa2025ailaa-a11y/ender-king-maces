advancement revoke @s only enderking:kill
scoreboard players add @s ek_kills 1
scoreboard players set @s ek_tier 0
execute if score @s ek_kills matches 3.. run scoreboard players set @s ek_tier 1
execute if score @s ek_kills matches 8.. run scoreboard players set @s ek_tier 2
execute if score @s ek_kills matches 15.. run scoreboard players set @s ek_tier 3
execute if score @s ek_kills matches 25.. run scoreboard players set @s ek_tier 4
execute if score @s ek_kills matches 40.. run scoreboard players set @s ek_tier 5
execute if score @s ek_kills matches 60.. run scoreboard players set @s ek_tier 6
execute if score @s ek_tier > @s ek_tier_last run function enderking:upgrade
execute if score @s ek_tier_last matches 3 run function enderking:ability/gold_kill
execute if score @s ek_tier_last matches 6 run function enderking:ability/netherite_kill
title @s actionbar [{text:"Mace kills: ",color:"yellow"},{score:{name:"@s",objective:"ek_kills"},color:"white"}]
