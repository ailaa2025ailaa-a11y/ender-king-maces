advancement revoke @s only enderking:hit
execute if score @s ek_tier_last matches 1 run function enderking:ability/stone
execute if score @s ek_tier_last matches 2 run function enderking:ability/copper
execute if score @s ek_tier_last matches 4 run function enderking:ability/iron
execute if score @s ek_tier_last matches 5 run function enderking:ability/diamond
execute if score @s ek_tier_last matches 6 run function enderking:ability/netherite
