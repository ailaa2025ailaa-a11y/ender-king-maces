effect give @s minecraft:strength 4 0
particle minecraft:enchant ~ ~1 ~ 0.4 0.6 0.4 0.5 20
