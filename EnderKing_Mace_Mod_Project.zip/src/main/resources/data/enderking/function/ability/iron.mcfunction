effect give @s minecraft:resistance 3 0
particle minecraft:crit ~ ~1 ~ 0.4 0.6 0.4 0.2 10
