effect give @s minecraft:instant_health 1 0
particle minecraft:heart ~ ~1.5 ~ 0.3 0.3 0.3 0.1 6
