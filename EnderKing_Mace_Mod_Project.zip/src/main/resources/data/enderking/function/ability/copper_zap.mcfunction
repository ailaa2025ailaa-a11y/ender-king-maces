effect give @s minecraft:instant_damage 1 0
particle minecraft:electric_spark ~ ~1 ~ 0.4 0.6 0.4 0.3 25
playsound minecraft:entity.lightning_bolt.thunder master @a ~ ~ ~ 0.3 2
