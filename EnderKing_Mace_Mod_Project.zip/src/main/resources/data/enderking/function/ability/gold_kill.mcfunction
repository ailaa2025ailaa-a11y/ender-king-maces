experience add @s 10 points
effect give @s minecraft:absorption 10 0
particle minecraft:happy_villager ~ ~1 ~ 0.4 0.6 0.4 0.1 15
