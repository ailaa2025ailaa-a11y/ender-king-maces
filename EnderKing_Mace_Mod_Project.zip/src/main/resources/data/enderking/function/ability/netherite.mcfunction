effect give @e[distance=0.01..4,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:armor_stand] minecraft:wither 4 1
execute at @e[distance=0.01..4,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:armor_stand] run particle minecraft:soul_fire_flame ~ ~1 ~ 0.4 0.6 0.4 0.05 15
