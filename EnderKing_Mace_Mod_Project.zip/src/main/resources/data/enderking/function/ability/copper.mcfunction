tag @e[distance=0.01..5,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:armor_stand,sort=nearest,limit=1] add ek_shock_target
execute if predicate enderking:chance_25 as @e[tag=ek_shock_target] at @s run function enderking:ability/copper_zap
tag @e[tag=ek_shock_target] remove ek_shock_target
