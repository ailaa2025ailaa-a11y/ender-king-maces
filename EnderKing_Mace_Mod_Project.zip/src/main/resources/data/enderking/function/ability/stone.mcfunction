effect give @e[distance=0.01..5,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:armor_stand,sort=nearest,limit=1] minecraft:slowness 3 1
execute at @e[distance=0.01..5,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:armor_stand,sort=nearest,limit=1] run particle minecraft:cloud ~ ~1 ~ 0.3 0.3 0.3 0.05 12
