scoreboard players set @s ek_deaths 0
execute if score @s ek_tier_last matches 0 run function enderking:mace/give_0
execute if score @s ek_tier_last matches 1 run function enderking:mace/give_1
execute if score @s ek_tier_last matches 2 run function enderking:mace/give_2
execute if score @s ek_tier_last matches 3 run function enderking:mace/give_3
execute if score @s ek_tier_last matches 4 run function enderking:mace/give_4
execute if score @s ek_tier_last matches 5 run function enderking:mace/give_5
execute if score @s ek_tier_last matches 6 run function enderking:mace/give_6
