scoreboard players set @s ek_kills 0
scoreboard players set @s ek_tier 0
scoreboard players set @s ek_tier_last 0
tellraw @s {text:"Ender King Mace progress reset",color:"red"}
