execute as @a[tag=!ek_started] run function enderking:start
execute as @a[tag=ek_started,scores={ek_deaths=1..}] run function enderking:respawn
