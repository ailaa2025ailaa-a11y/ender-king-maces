scoreboard players operation @s ek_tier_last = @s ek_tier
execute if score @s ek_tier_last matches 1 run function enderking:mace/set_1
execute if score @s ek_tier_last matches 1 run title @s title {text:"Stone Mace",color:"gray"}
execute if score @s ek_tier_last matches 1 run title @s subtitle {text:"Ability unlocked: Crushing Blow",color:"yellow"}
execute if score @s ek_tier_last matches 2 run function enderking:mace/set_2
execute if score @s ek_tier_last matches 2 run title @s title {text:"Copper Mace",color:"#B87333"}
execute if score @s ek_tier_last matches 2 run title @s subtitle {text:"Ability unlocked: Static Shock",color:"yellow"}
execute if score @s ek_tier_last matches 3 run function enderking:mace/set_3
execute if score @s ek_tier_last matches 3 run title @s title {text:"Gold Mace",color:"gold"}
execute if score @s ek_tier_last matches 3 run title @s subtitle {text:"Ability unlocked: Greed",color:"yellow"}
execute if score @s ek_tier_last matches 4 run function enderking:mace/set_4
execute if score @s ek_tier_last matches 4 run title @s title {text:"Iron Mace",color:"#D8D8D8"}
execute if score @s ek_tier_last matches 4 run title @s subtitle {text:"Ability unlocked: Iron Guard",color:"yellow"}
execute if score @s ek_tier_last matches 5 run function enderking:mace/set_5
execute if score @s ek_tier_last matches 5 run title @s title {text:"Diamond Mace",color:"aqua"}
execute if score @s ek_tier_last matches 5 run title @s subtitle {text:"Ability unlocked: Battle Rush",color:"yellow"}
execute if score @s ek_tier_last matches 6 run function enderking:mace/set_6
execute if score @s ek_tier_last matches 6 run title @s title {text:"Netherite Mace",color:"#7A6A75"}
execute if score @s ek_tier_last matches 6 run title @s subtitle {text:"Ability unlocked: Wither Wrath",color:"yellow"}
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 0.8 0.5 0.3 40
