tag @s add ek_started
scoreboard players set @s ek_kills 0
scoreboard players set @s ek_tier 0
scoreboard players set @s ek_tier_last 0
scoreboard players set @s ek_deaths 0
function enderking:mace/give_0
tellraw @s {text:"You received the Wood Mace. Get kills to evolve it!",color:"gold"}
