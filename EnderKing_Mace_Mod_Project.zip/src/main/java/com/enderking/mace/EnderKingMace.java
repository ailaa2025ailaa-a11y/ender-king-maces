package com.enderking.mace;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EnderKingMace implements ModInitializer {
	public static final String MOD_ID = "enderking_mace";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		// The evolving mace logic lives in the built-in data pack
		// (src/main/resources/data/enderking). Fabric loads it automatically.
		LOGGER.info("Ender King Mace loaded");
	}
}
